// Can this ever change?
pub const CHALLENGE_SIZE_BYTES: usize = 32;
// Allegedly this is milliseconds?
pub const AUTHENTICATOR_TIMEOUT: u32 = 60000;
