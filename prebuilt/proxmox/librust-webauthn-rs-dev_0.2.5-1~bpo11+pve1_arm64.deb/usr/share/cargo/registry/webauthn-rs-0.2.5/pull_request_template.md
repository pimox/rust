Implements # .

- [ ] cargo fmt has been run
- [ ] cargo test has been run and passes
- [ ] documentation has been updated with relevant examples (if relevant)
