/* Just use installed headers */
#include <zstd.h>
#include <zdict.h>
